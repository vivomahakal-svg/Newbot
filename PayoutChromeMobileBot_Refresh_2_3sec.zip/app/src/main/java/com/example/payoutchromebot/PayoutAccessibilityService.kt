package com.example.payoutchromebot

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import java.util.Locale

class PayoutAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var botOn = false
    private var busy = false
    private var overlay: View? = null
    private var status: TextView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        showOverlay()
        tick()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun prefs() = getSharedPreferences("bot", MODE_PRIVATE)

    private fun tick() {
        handler.postDelayed({
            if (botOn && !busy) runCycle()
            tick()
        }, ((prefs().getString("seconds","2")?.toLongOrNull() ?: 2L).coerceIn(2L,3L))*1000L)
    }

    private fun runCycle() {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != "com.android.chrome") return
        busy = true
        setStatus("Refreshing")
        clickText(root, "Refresh list")

        handler.postDelayed({
            val r = rootInActiveWindow
            if (r == null || r.packageName?.toString() != "com.android.chrome") {
                busy=false; return@postDelayed
            }
            val process = findText(r, "Accept for processing")
            if (process == null) {
                setStatus("Waiting")
                busy=false
                return@postDelayed
            }

            val amount = amountNear(process)
            val min = prefs().getString("min","0")?.toDoubleOrNull() ?: 0.0
            val max = prefs().getString("max","0")?.toDoubleOrNull() ?: 0.0
            if (!allowed(amount,min,max)) {
                setStatus("Outside amount limit")
                busy=false
                return@postDelayed
            }

            setStatus("Processing")
            clickNode(process)

            handler.postDelayed({
                val rr = rootInActiveWindow
                val accept = rr?.let { findConfirmationAccept(it) }
                if (accept != null) {
                    val a2 = amountNear(accept) ?: amount
                    if (allowed(a2,min,max)) {
                        clickNode(accept)
                        setStatus("Accepted")
                    } else setStatus("Confirmation outside limit")
                } else setStatus("Confirmation not found")
                busy=false
            },800)
        },900)
    }

    private fun allowed(a: Double?, min: Double, max: Double): Boolean {
        if (a == null && (min > 0 || max > 0)) return false
        if (a == null) return true
        if (min > 0 && a < min) return false
        if (max > 0 && a > max) return false
        return true
    }

    private fun findText(root: AccessibilityNodeInfo, s: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByText(s).firstOrNull { it.isVisibleToUser }

    private fun clickText(root: AccessibilityNodeInfo, s: String): Boolean {
        val n = findText(root,s) ?: return false
        return clickNode(n)
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        var p=n.parent
        repeat(6) {
            if (p == null) return false
            if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            p=p.parent
        }
        return false
    }

    private fun amountNear(n0: AccessibilityNodeInfo): Double? {
        var n: AccessibilityNodeInfo? = n0
        repeat(6) {
            if (n==null) return null
            val t=(n.text?.toString().orEmpty()+" "+n.contentDescription?.toString().orEmpty())
            val m=Regex("(?i)(?:₹|INR)\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)").find(t)
            if (m!=null) return m.groupValues[1].replace(",","").toDoubleOrNull()
            n=n.parent
        }
        return null
    }

    private fun findConfirmationAccept(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val nodes=root.findAccessibilityNodeInfosByText("Accept")
        return nodes.firstOrNull { it.isVisibleToUser && hasAncestor(it,"Accept the request for processing") }
            ?: nodes.firstOrNull { it.isVisibleToUser }
    }

    private fun hasAncestor(n0: AccessibilityNodeInfo, phrase:String):Boolean {
        var n=n0.parent
        repeat(6) {
            if(n==null) return false
            val t=n.text?.toString().orEmpty()+" "+n.contentDescription?.toString().orEmpty()
            if(t.contains(phrase,true)) return true
            n=n.parent
        }
        return false
    }

    private fun setStatus(s:String) { status?.text="BOT: $s" }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this) || overlay!=null) return
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(10,6,10,6)
            setBackgroundColor(0xEE202124.toInt())
        }
        status=TextView(this).apply { text="BOT: OFF"; setTextColor(0xFFFFFFFF.toInt()) }
        box.addView(status)
        val sw=Switch(this).apply {
            text="Auto Accept"; setTextColor(0xFFFFFFFF.toInt())
            setOnCheckedChangeListener { _,checked -> botOn=checked; setStatus(if(checked)"ON" else "OFF") }
        }
        box.addView(sw)

        val lp=WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity=Gravity.TOP or Gravity.END
        lp.x=12; lp.y=90
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box,lp)
        overlay=box
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        overlay?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch(_:Exception){} }
        overlay=null
        super.onDestroy()
    }
}
