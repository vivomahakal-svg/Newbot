package com.example.payoutchromebot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val min = findViewById<EditText>(R.id.minAmount)
        val max = findViewById<EditText>(R.id.maxAmount)
        val sec = findViewById<EditText>(R.id.refreshSeconds)
        val p = getSharedPreferences("bot", MODE_PRIVATE)

        min.setText(p.getString("min", "0"))
        max.setText(p.getString("max", "0"))
        sec.setText(p.getString("seconds", "2"))

        findViewById<Button>(R.id.openAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.openOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        findViewById<Button>(R.id.save).setOnClickListener {
            val s = (sec.text.toString().toLongOrNull() ?: 2L).coerceIn(2L, 3L)
            p.edit().putString("min", min.text.toString().ifBlank { "0" })
                .putString("max", max.text.toString().ifBlank { "0" })
                .putString("seconds", s.toString()).apply()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }
    }
}
