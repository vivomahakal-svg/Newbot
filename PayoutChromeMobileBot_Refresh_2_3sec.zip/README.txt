MOBILE CHROME VERSION

This project is designed so the USER'S NORMAL CHROME browser remains the page shown on screen.
An Android Accessibility Service reads visible Chrome controls and clicks:
Refresh list -> Accept for processing -> confirmation Accept.

Controls:
- Floating Auto Accept ON/OFF
- Minimum amount
- Maximum amount
- Refresh interval (2 or 3 seconds)

Setup:
1. Build/install the APK with Android Studio.
2. Open the app.
3. Enable its Accessibility Service in Android Settings.
4. Allow Display over other apps.
5. Open Chrome and log in to the payout site.
6. Open the payout page.
7. Use the floating Auto Accept switch.

Keep Chrome visible for reliable operation.
The bot does not bypass CAPTCHA, OTP, 2FA, or access controls.
If the website changes its visible wording/layout, selectors may need updating.
